<?php 
// Name: Mr. CHUNG YHUNG YIE
// Project Name: footer.php
// Description: outputs a simple HTML footer containing a heading that says “By The Enthusiasts.”

// First Written: 1/6/2025
// Last Modified: 3/6/2025 
    include('embed.php'); 
?>
<footer>
    <h2>By The Enthusiasts</h2>
</footer>