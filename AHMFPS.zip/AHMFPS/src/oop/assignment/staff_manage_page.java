/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package oop.assignment;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author ezjiet
 */
public class staff_manage_page extends javax.swing.JFrame {

    private DefaultTableModel model = new DefaultTableModel();
    private String columnName[] = {"Name", "NRIC", "Room Number", "Email", "Role", "Phone Number", "Password", "Room Type", "Status"};
    int row = -1;

    /**
     * Creates new form staffmanage_page
     */
    public staff_manage_page() {
        
        try{
            model.setColumnIdentifiers(columnName);
           
            FileReader fr = new FileReader("D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userDetails.txt");
            BufferedReader br = new BufferedReader(fr);
        
            String line = null;  

            while((line = br.readLine()) != null){
                String value[] = line.split(", ");
                String role = value[4];
                if (role.equals("Resident") || role.equals("Staff")) 
                model.addRow(value); 
            }
                   
            br.close();
            fr.close();
        
        } catch(IOException e){
            
        }
        
        initComponents();
        setLocationRelativeTo(null);
    }
    
    private void saveDataToFile1() {
        String filePath = "D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userDetails.txt";
        List<String> managerRecords = new ArrayList<>();

        // Read existing file and store manager details
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(", Manager,")) { // Check if role is "Manager"
                    managerRecords.add(line);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading existing data.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Write all user details
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Write displayed users (Resident and Staff from table)
            for (int i = 0; i < model.getRowCount(); i++) {
                String name = model.getValueAt(i, 0).toString();
                String nric = model.getValueAt(i,1).toString();
                String roomNumber = model.getValueAt(i, 2).toString();
                String email = model.getValueAt(i, 3).toString();
                String role = model.getValueAt(i, 4).toString();
                String phoneNumber = model.getValueAt(i, 5).toString();
                String password = model.getValueAt(i, 6).toString();
                String roomType = model.getValueAt(i, 7).toString();
                String status = model.getValueAt(i, 8).toString();

                // Write user details (Resident and Staff)
                writer.write(name + ", " + nric + ", " + roomNumber + ", " + email + ", " + role + ", " + phoneNumber + ", " + password + ", " + roomType + ", " + status);
                writer.newLine();
            }

            // Send Manager records back
            for (String manager : managerRecords) {
                writer.write(manager);
                writer.newLine();
            }

            JOptionPane.showMessageDialog(this, "User details saved successfully!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while saving data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void saveDataToFile2() {
        String filePath = "D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userPaymentDetails.txt";
        List<String> managerRecords = new ArrayList<>();

        // Read existing file and store details of users with Room Number 903 (Manager Code)
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length > 2 && parts[2].equals("903")) { // Check if room number is 903
                    managerRecords.add(line);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading existing data.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Write all user details including room 903 records
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Write displayed users (Resident and Staff from table)
            for (int i = 0; i < model.getRowCount(); i++) {
                String name = model.getValueAt(i, 0).toString();
                String nric = model.getValueAt(i, 1).toString();
                String roomNumber = model.getValueAt(i, 2).toString();
                String roomType = model.getValueAt(i, 7).toString();
                Double balance = 0.0;

                // Write user payment details (Resident and Staff)
                writer.write(name + ", " + nric + ", " + roomNumber + ", " + roomType + ", " + balance);
                writer.newLine();
            }

            // Send records with room number 903 back
            for (String record : managerRecords) {
                writer.write(record);
                writer.newLine();
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while saving data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        add = new javax.swing.JButton();
        manageUserDetailsTitle = new javax.swing.JLabel();
        update = new javax.swing.JButton();
        nameInput = new javax.swing.JTextField();
        back = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        roleInput = new javax.swing.JComboBox<>();
        nric = new javax.swing.JLabel();
        roomNumberInput = new javax.swing.JTextField();
        email = new javax.swing.JLabel();
        passwordInput = new javax.swing.JTextField();
        phoneNumber = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        roomNumber = new javax.swing.JLabel();
        emailInput = new javax.swing.JTextField();
        role = new javax.swing.JLabel();
        phoneNumberInput = new javax.swing.JTextField();
        password = new javax.swing.JLabel();
        roomType = new javax.swing.JLabel();
        roomTypeInput = new javax.swing.JComboBox<>();
        nricInput = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        add.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        add.setText("Add");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        manageUserDetailsTitle.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        manageUserDetailsTitle.setText("Manage User Details");

        update.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        nameInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        back.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable1.setModel(model);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable1MouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        roleInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roleInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Resident", "Staff", "Manager"}));

        nric.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nric.setText("NRIC : ");

        roomNumberInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        email.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email.setText("Email :");

        passwordInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        phoneNumber.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        phoneNumber.setText("Phone Number :");

        name.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name.setText("Name :");

        roomNumber.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roomNumber.setText("Room Number :");

        emailInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        role.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        role.setText("Role :");

        phoneNumberInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password.setText("Password :");

        roomType.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roomType.setText("Room Type :");

        roomTypeInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roomTypeInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Type A", "Type B", "Type C", "Staff/Manager"}));

        nricInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(462, 462, 462)
                        .addComponent(manageUserDetailsTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(roomNumber))
                                    .addComponent(nric, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(59, 59, 59)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nricInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(roomNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(role)
                                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(phoneNumber)
                                    .addComponent(password)
                                    .addComponent(roomType, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(58, 58, 58)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(roleInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(emailInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(phoneNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(roomTypeInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(update)
                                        .addGap(18, 18, 18)
                                        .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(39, 39, 39)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 980, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(manageUserDetailsTitle)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(name)
                                .addComponent(nameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(nric)
                                    .addComponent(nricInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(roomNumber)
                            .addComponent(roomNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(emailInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(email))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(roleInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(role))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(phoneNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phoneNumber))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(password))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(roomTypeInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roomType))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(add)
                            .addComponent(update)
                            .addComponent(back)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jScrollPane1)))
                .addGap(26, 26, 26))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        // TODO add your handling code here:
        String name = nameInput.getText();
        String nric = nricInput.getText();
        String roomNumber = roomNumberInput.getText();
        String email = emailInput.getText();
        String role = roleInput.getSelectedItem().toString();
        String phoneNumber = phoneNumberInput.getText();
        String password = passwordInput.getText();
        String roomType = roomTypeInput.getSelectedItem().toString();
        
        boolean isValidRoomType = true;
        if (role.equalsIgnoreCase("Resident")) {
            if (!roomNumber.matches("10[1-9]|1[1-9][0-9]|200")) {
                JOptionPane.showMessageDialog(this, "Invalid Room Number for Resident!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        } else if (role.equalsIgnoreCase("Staff")) {
            if (!roomNumber.equals("305")) {
                JOptionPane.showMessageDialog(this, "Invalid Staff Code!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        } else if (role.equalsIgnoreCase("Manager")) {
            if (!roomNumber.equals("903")) {
                JOptionPane.showMessageDialog(this, "Invalid Manager Code!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        }

        if (!isValidRoomType) return; // Stop execution if room type is invalid

        String errorMessage = null;
        if (!RegisterValidator.isValidName(name)) {
            errorMessage = "Invalid name. Name must contain only letters and spaces.";
        } else if (!RegisterValidator.isValidNRIC(nric)) {
            errorMessage = "Invalid NRIC. NRIC must contain only numbers and be 12 digits long.";
        } else if (!RegisterValidator.isValidRoomNumber(roomNumber)) {
            errorMessage = "Invalid room number. Room Number must be a number between 101 and 200.";
        } else if (!RegisterValidator.isValidEmail(email)) {
            errorMessage = "Invalid email format.";
        } else if (!RegisterValidator.isValidPhoneNumber(phoneNumber)) {
            errorMessage = "Invalid phone number. Phone Number must be 10 or 11 digits long.";
        } else if (!RegisterValidator.isValidPassword(password)) {
            errorMessage = "Invalid password. Password must be provided.";
        }

        if (errorMessage != null) {
            JOptionPane.showMessageDialog(this, errorMessage, "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String[] values = {name, nric, roomNumber, email, role, phoneNumber, password, roomType, "Pending"};
        model.addRow(values);

        saveDataToFile1();
        saveDataToFile2();

        nameInput.setText("");
        nricInput.setText("");
        roomNumberInput.setText("");
        emailInput.setText("");
        roleInput.setSelectedIndex(0);
        phoneNumberInput.setText("");
        passwordInput.setText("");
        roomTypeInput.setSelectedIndex(0);
    }//GEN-LAST:event_addActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();

        if (row == -1){
            JOptionPane.showMessageDialog(this, "Please select a row");
            return;
        }

        String name = nameInput.getText();
        String nric = nricInput.getText();
        String roomNumber = roomNumberInput.getText();
        String email = emailInput.getText();
        String role = roleInput.getSelectedItem().toString();
        String phoneNumber = phoneNumberInput.getText();
        String password = passwordInput.getText();
        String roomType = roomTypeInput.getSelectedItem().toString();

        boolean isValidRoomType = true;
        if (role.equalsIgnoreCase("Resident")) {
            if (!roomNumber.matches("10[1-9]|1[1-9][0-9]|200")) {
                JOptionPane.showMessageDialog(this, "Invalid Room Number for Resident!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        } else if (role.equalsIgnoreCase("Staff")) {
            if (!roomNumber.equals("305")) {
                JOptionPane.showMessageDialog(this, "Invalid Staff Code!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        } else if (role.equalsIgnoreCase("Manager")) {
            if (!roomNumber.equals("903")) {
                JOptionPane.showMessageDialog(this, "Invalid Manager Code!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        }

        if (!isValidRoomType) return; // Stop execution if room type is invalid

        String errorMessage = null;
        if (!RegisterValidator.isValidName(name)) {
            errorMessage = "Invalid name. Name must contain only letters and spaces.";
        } else if (!RegisterValidator.isValidNRIC(nric)) {
            errorMessage = "Invalid NRIC. NRIC must contain only numbers and be 12 digits long.";
        } else if (!RegisterValidator.isValidRoomNumber(roomNumber)) {
            errorMessage = "Invalid room number. Room Number must be a number between 101 and 200.";
        } else if (!RegisterValidator.isValidEmail(email)) {
            errorMessage = "Invalid email format.";
        } else if (!RegisterValidator.isValidPhoneNumber(phoneNumber)) {
            errorMessage = "Invalid phone number. Phone Number must be 10 or 11 digits long.";
        } else if (!RegisterValidator.isValidPassword(password)) {
            errorMessage = "Invalid password. Password must be provided.";
        }

        if (errorMessage != null) {
            JOptionPane.showMessageDialog(this, errorMessage, "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        model.setValueAt(name, row, 0);
        model.setValueAt(nric, row, 1);
        model.setValueAt(roomNumber, row, 2);
        model.setValueAt(email, row, 3);
        model.setValueAt(role, row, 4);
        model.setValueAt(phoneNumber, row, 5);
        model.setValueAt(password, row, 6);
        model.setValueAt(roomType, row, 7);
        model.setValueAt("Pending", row, 8);

        saveDataToFile1();
        saveDataToFile2();

        nameInput.setText("");
        nricInput.setText("");
        roomNumberInput.setText("");
        emailInput.setText("");
        roleInput.setSelectedIndex(0);
        phoneNumberInput.setText("");
        passwordInput.setText("");
        roomTypeInput.setSelectedIndex(0);
    }//GEN-LAST:event_updateActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        new staff_menu_page().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    private void jTable1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseReleased
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();

        String name = String.valueOf(model.getValueAt(row,0));
        String nric = String.valueOf(model.getValueAt(row,1));
        String roomNumber = String.valueOf(model.getValueAt(row,2));
        String email = String.valueOf(model.getValueAt(row,3));
        String role = String.valueOf(model.getValueAt(row,4));
        String phoneNumber = String.valueOf(model.getValueAt(row,5));
        String password = String.valueOf(model.getValueAt(row,6));
        String roomType = String.valueOf(model.getValueAt(row, 7));

        nameInput.setText(name);
        nricInput.setText(nric);
        roomNumberInput.setText(roomNumber);
        emailInput.setText(email);
        roleInput.setSelectedItem(role);
        phoneNumberInput.setText(phoneNumber);
        passwordInput.setText(password);
        roomTypeInput.setSelectedItem(roomType);
    }//GEN-LAST:event_jTable1MouseReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(staff_manage_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(staff_manage_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(staff_manage_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(staff_manage_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new staff_manage_page().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JButton back;
    private javax.swing.JLabel email;
    private javax.swing.JTextField emailInput;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel manageUserDetailsTitle;
    private javax.swing.JLabel name;
    private javax.swing.JTextField nameInput;
    private javax.swing.JLabel nric;
    private javax.swing.JTextField nricInput;
    private javax.swing.JLabel password;
    private javax.swing.JTextField passwordInput;
    private javax.swing.JLabel phoneNumber;
    private javax.swing.JTextField phoneNumberInput;
    private javax.swing.JLabel role;
    private javax.swing.JComboBox<String> roleInput;
    private javax.swing.JLabel roomNumber;
    private javax.swing.JTextField roomNumberInput;
    private javax.swing.JLabel roomType;
    private javax.swing.JComboBox<String> roomTypeInput;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
