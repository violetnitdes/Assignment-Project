/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.assignment;

/**
 *
 * @author ezjiet
 */
public class RegisterValidator {
    // Validate Name (letters and spaces only)
    public static boolean isValidName(String name) {
        return name != null && name.matches("[a-zA-Z ]+");
    }
    
    // Validate NRIC (12-digit number)
    public static boolean isValidNRIC(String nric) {
        return nric != null && nric.matches("[0-9]{12}");
    }
    
    // Validate Room Number (101-200)
    public static boolean isValidRoomNumber(String roomNumber) {
        try {
            int number = Integer.parseInt(roomNumber);
            return number >= 101 && number <= 200 || number == 305 || number == 903;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    // Validate Email
    public static boolean isValidEmail(String email) {
        return email != null && email.matches("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.com$");
    }
    
    // Validate Phone Number (10-11 digit number)
    public static boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.matches("^[0-9]{10,11}$");
    }  
        
    // Validate Password
    public static boolean isValidPassword(String password) {
        return password != null && !password.isEmpty();
    }
    
    // Validate if the password and confirmation password are the same
    public static boolean isValidConfirmPassword(String password, String confirmPassword) {
        return confirmPassword != null && !confirmPassword.trim().isEmpty() && confirmPassword.equals(password);
    }  
}
