/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.assignment;

/**
 *
 * @author ezjiet
 */

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

public class DetailsSaving {
    // Define file paths as constants
    private static final String USER_DETAILS_FILE = "D:/APU File/Diploma Semester 4/Object Oriented Programming/Assignment/txt file/userDetails.txt";
    private static final String USER_PAYMENT_DETAILS_FILE = "D:/APU File/Diploma Semester 4/Object Oriented Programming/Assignment/txt file/userPaymentDetails.txt";

    // Method to save user details with a "Pending" status
    public void saveUserDetails(String name, String nric, String roomNumber, String email, String role, String phoneNumber, String password, String confirmPassword, String roomType, String status, double balance) {
        saveToFile(USER_DETAILS_FILE, name + ", " + nric + ", " + roomNumber + ", " + email + ", " + role + ", " + phoneNumber + ", " + password + ", " + roomType + ", " + status);
    }

    // Method to save user payment details
    public void saveUserPaymentDetails(String name, String nric, String roomNumber, String email, String role, String phoneNumber, String password, String confirmPassword, String roomType, String status, double balance) {
        saveToFile(USER_PAYMENT_DETAILS_FILE, name + ", " + nric + ", " + roomNumber + ", " + roomType + ", " + balance);
    }

    // Generic method for writing to a file
    private void saveToFile(String filePath, String data) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(data);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving data to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
