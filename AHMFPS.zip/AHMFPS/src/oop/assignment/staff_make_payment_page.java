package oop.assignment;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author ezjiet
 */
public class staff_make_payment_page extends javax.swing.JFrame {
    
    private DefaultTableModel model = new DefaultTableModel();
    private String columnName[] = {"Invoice No.", "Name", "NRIC", "Room Number", "Email", "Role", "Phone Number", "Room Type", "Amount", "Payment Method", "Payment Date and Time", "Payment Status"};
    int row = -1;

    /**
     * Creates new form staff_make_payment_page_new
     */
    public staff_make_payment_page() {
        
        try{
            model.setColumnIdentifiers(columnName);
           
            FileReader fr = new FileReader("D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\invoice.txt");
            BufferedReader br = new BufferedReader(fr);
        
            String line = null;  

            while((line = br.readLine()) != null){
                String value[] = line.split(", ");
                model.addRow(value); 
            }
                   
            br.close();
            fr.close();
        
        } catch(IOException e){
            
        }
        
        initComponents();
        setLocationRelativeTo(null);
    }
    
    private void saveDataToFile() {
        String filePath = "D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\invoice.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < model.getRowCount(); i++) {
                String invoiceStr = model.getValueAt(i, 0).toString();
                String name = model.getValueAt(i, 1).toString();
                String nric = model.getValueAt(i, 2).toString();
                String roomNumber = model.getValueAt(i, 3).toString();
                String email = model.getValueAt(i, 4).toString();
                String role = model.getValueAt(i, 5).toString();
                String phoneNumber = model.getValueAt(i, 6).toString();
                String roomType = model.getValueAt(i, 7).toString();
                String amount = model.getValueAt(i, 8).toString();
                String paymentMethod = model.getValueAt(i, 9).toString();
                String paymentDateTime = model.getValueAt(i, 10).toString();
                String paymentStatus = model.getValueAt(i, 11).toString();
                
                writer.write(invoiceStr + ", " + name + ", " + nric + ", " + roomNumber + ", " + email + ", " + role + ", " + phoneNumber + ", " + roomType + ", " + amount + ", " + paymentMethod + ", " + paymentDateTime + ", " + paymentStatus);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while saving data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void generateReceipt(int selectedRow) {
        String invoiceNo = model.getValueAt(selectedRow, 0).toString();
        String name = model.getValueAt(selectedRow, 1).toString();
        String nric = model.getValueAt(selectedRow, 2).toString();
        String roomNumber = model.getValueAt(selectedRow, 3).toString();
        String email = model.getValueAt(selectedRow, 4).toString();
        String role = model.getValueAt(selectedRow, 5).toString();
        String phoneNumber = model.getValueAt(selectedRow, 6).toString();
        String roomType = model.getValueAt(selectedRow, 7).toString();
        String amount = model.getValueAt(selectedRow, 8).toString();
        String paymentMethod = model.getValueAt(selectedRow, 9).toString();
        String paymentDateTime = model.getValueAt(selectedRow, 10).toString();
        String paymentStatus = model.getValueAt(selectedRow, 11).toString();

        if (paymentStatus.equals("Paid")) {
            String receipt = "Receipt\n" +
                             "Invoice No.: " + invoiceNo + "\n" +
                             "Name: " + name + "\n" +
                             "NRIC: " + nric + "\n" +
                             "Room Number: " + roomNumber + "\n" +
                             "Email: " + email + "\n" +
                             "Phone Number: " + phoneNumber + "\n" +
                             "Room Type: " + roomType + "\n" +
                             "Amount: " + amount + "\n" +
                             "Payment Method: " + paymentMethod + "\n" +
                             "Payment Date and Time: " + paymentDateTime + "\n" +
                             "Payment Status: " + paymentStatus;

            JOptionPane.showMessageDialog(this, receipt, "Receipt", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Payment has not been completed for this invoice.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        makePayment = new javax.swing.JButton();
        back = new javax.swing.JButton();
        paymentMethodInput = new javax.swing.JComboBox<>();
        generateReceipt = new javax.swing.JButton();
        makePaymentTitle = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable1.setModel(model);
        jScrollPane1.setViewportView(jTable1);

        makePayment.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        makePayment.setText("Make Payment");
        makePayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                makePaymentActionPerformed(evt);
            }
        });

        back.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        paymentMethodInput.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        paymentMethodInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bank Transfer", "Cash", "E-wallet", "Credit Card"}));

        generateReceipt.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        generateReceipt.setText("Generate Receipt");
        generateReceipt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generateReceiptActionPerformed(evt);
            }
        });

        makePaymentTitle.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        makePaymentTitle.setText("Make Payment");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addComponent(paymentMethodInput, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(157, 157, 157)
                .addComponent(makePayment, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(137, 137, 137)
                .addComponent(generateReceipt, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
                .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(114, 114, 114))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1367, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(makePaymentTitle)
                        .addGap(544, 544, 544))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(makePaymentTitle)
                .addGap(42, 42, 42)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(makePayment, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(paymentMethodInput, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(generateReceipt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(118, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void makePaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_makePaymentActionPerformed
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();
        
        if (row == -1){
            JOptionPane.showMessageDialog(this,"Please select a row");
        } else {
            String paymentMethod = paymentMethodInput.getSelectedItem().toString();

            // Get current date and time
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String dateTime = now.format(formatter);
            
            // Update the selected row's payment method and status
            model.setValueAt(paymentMethod, row, 9);
            model.setValueAt(dateTime, row, 10);
            model.setValueAt("Paid", row, 11);
           
            saveDataToFile();

            JOptionPane.showMessageDialog(this, "Payment successful!");
        }
    }//GEN-LAST:event_makePaymentActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        new staff_menu_page().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    private void generateReceiptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generateReceiptActionPerformed
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();
        
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to generate receipt.");
        } else {
            generateReceipt(row);
        }
    }//GEN-LAST:event_generateReceiptActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(staff_make_payment_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(staff_make_payment_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(staff_make_payment_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(staff_make_payment_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new staff_make_payment_page().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JButton generateReceipt;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton makePayment;
    private javax.swing.JLabel makePaymentTitle;
    private javax.swing.JComboBox<String> paymentMethodInput;
    // End of variables declaration//GEN-END:variables
}
