/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package oop.assignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ezjiet
 */
public class manager_manage_page extends javax.swing.JFrame {
    
    private DefaultTableModel model = new DefaultTableModel();
    private String columnName[] = {"Name", "NRIC", "Room Number", "Email", "Role", "Phone Number", "Password", "Room Type", "Status"};
    int row = -1;

    /**
     * Creates new form manager_manage_page
     */
    public manager_manage_page() {
        
        try{
            model.setColumnIdentifiers(columnName);
           
            FileReader fr = new FileReader("D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userDetails.txt");
            BufferedReader br = new BufferedReader(fr);
        
            String line = null;  

            while((line = br.readLine()) != null){
                String value[] = line.split(", ");
                model.addRow(value); 
            }
                   
            br.close();
            fr.close();
        
        } catch(IOException e){
            
        }
        
        initComponents();
        setLocationRelativeTo(null);
    }
    
    private void saveDataToFile1() {
        String filePath = "D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userDetails.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            
            for (int i = 0; i < model.getRowCount(); i++) {
                String name = model.getValueAt(i, 0).toString();
                String nric = model.getValueAt(i,1).toString();
                String roomNumber = model.getValueAt(i, 2).toString();
                String email = model.getValueAt(i, 3).toString();
                String role = model.getValueAt(i, 4).toString();
                String phoneNumber = model.getValueAt(i, 5).toString();
                String password = model.getValueAt(i, 6).toString();
                String roomType = model.getValueAt(i, 7).toString();
                String status = model.getValueAt(i, 8).toString();

                writer.write(name + ", " + nric + ", " + roomNumber + ", " + email + ", " + role + ", " + phoneNumber + ", " + password + ", " + roomType + ", " + status);
                writer.newLine();
            }
            JOptionPane.showMessageDialog(this, "User details saved successfully!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while saving data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void saveDataToFile2() {
        String filePath = "D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userPaymentDetails.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {

            for (int i = 0; i < model.getRowCount(); i++) {
                String name = model.getValueAt(i, 0).toString();
                String nric = model.getValueAt(i,1).toString();
                String roomNumber = model.getValueAt(i, 2).toString();
                String role = model.getValueAt(i, 4).toString();
                String roomType = model.getValueAt(i, 7).toString();
                Double balance = 0.0;

                writer.write(name + ", " + nric + ", " + roomNumber + ", " + roomType + ", " + balance);
                writer.newLine();
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while saving data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteFromFile(String filePath, String targetNRIC) {
        File inputFile = new File(filePath);
        File tempFile = new File("temp.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                String[] details = currentLine.split(", ");
                if (details.length > 1 && details[1].equals(targetNRIC)) {
                    continue; // Skip writing this line
                }
                writer.write(currentLine);
                writer.newLine();
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error updating file: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Replace old file with updated file
        if (!inputFile.delete()) {
            JOptionPane.showMessageDialog(this, "Could not delete old file: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!tempFile.renameTo(inputFile)) {
            JOptionPane.showMessageDialog(this, "Could not rename temp file to original: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        JOptionPane.showMessageDialog(this, "User details saved successfully!");
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        password = new javax.swing.JLabel();
        nameInput = new javax.swing.JTextField();
        delete = new javax.swing.JButton();
        update = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        roomNumberInput = new javax.swing.JTextField();
        add = new javax.swing.JButton();
        passwordInput = new javax.swing.JTextField();
        status = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        manageUserAccountTitle = new javax.swing.JLabel();
        roomNumber = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        role = new javax.swing.JLabel();
        phoneNumber = new javax.swing.JLabel();
        phoneNumberInput = new javax.swing.JTextField();
        email = new javax.swing.JLabel();
        emailInput = new javax.swing.JTextField();
        nric = new javax.swing.JLabel();
        roleInput = new javax.swing.JComboBox<>();
        statusInput = new javax.swing.JComboBox<>();
        roomType = new javax.swing.JLabel();
        nricInput = new javax.swing.JTextField();
        roomTypeInput = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password.setText("Password :");

        nameInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        delete.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        delete.setText("Delete");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        update.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable1.setModel(model);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable1MouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        roomNumberInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        add.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        add.setText("Add");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        passwordInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        status.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        status.setText("Status :");

        name.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name.setText("Name :");

        manageUserAccountTitle.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        manageUserAccountTitle.setText("Manage User Account");

        roomNumber.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roomNumber.setText("Room Number :");

        back.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        role.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        role.setText("Role :");

        phoneNumber.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        phoneNumber.setText("Phone Number :");

        phoneNumberInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        email.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        email.setText("Email :");

        emailInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        nric.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nric.setText("NRIC :");

        roleInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roleInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Resident", "Staff", "Manager"}));

        statusInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        statusInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Approved", "Denied", "Pending"}));

        roomType.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roomType.setText("Room Type :");

        nricInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        roomTypeInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        roomTypeInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"Type A", "Type B", "Type C", "Staff/Manager"}));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(update)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(delete, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nric, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nricInput, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                            .addComponent(nameInput)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(roomNumber)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(roomNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(role, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(roomType, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(status, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(phoneNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(emailInput)
                                .addComponent(roleInput, 0, 180, Short.MAX_VALUE)
                                .addComponent(phoneNumberInput)
                                .addComponent(passwordInput))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(statusInput, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(roomTypeInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(manageUserAccountTitle)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 949, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(manageUserAccountTitle)
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 11, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(name)
                            .addComponent(nameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nric)
                            .addComponent(nricInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(roomNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roomNumber))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(emailInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(email))
                        .addGap(18, 19, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(roleInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(role))
                        .addGap(18, 19, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(phoneNumber)
                            .addComponent(phoneNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 19, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(password)
                            .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 19, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(roomTypeInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roomType))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(statusInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(status))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(add)
                            .addComponent(delete)
                            .addComponent(update)
                            .addComponent(back)))
                    .addComponent(jScrollPane1))
                .addGap(46, 46, 46))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row");
            return;
        } 

        String role = model.getValueAt(row, 4).toString(); 
        String nric = model.getValueAt(row, 1).toString(); // Get NRIC for deletion reference

        model.removeRow(row);

        deleteFromFile("D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userDetails.txt", nric);
        deleteFromFile("D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userPaymentDetails.txt", nric);

        nameInput.setText("");
        nricInput.setText("");
        roomNumberInput.setText("");
        emailInput.setText("");
        roleInput.setSelectedIndex(0);
        phoneNumberInput.setText("");
        passwordInput.setText("");
        roomTypeInput.setSelectedIndex(0);
        statusInput.setSelectedIndex(0);
    }//GEN-LAST:event_deleteActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row");
            return;
        }

        String name = nameInput.getText();
        String nric = nricInput.getText();
        String roomNumber = roomNumberInput.getText();
        String email = emailInput.getText();
        String role = roleInput.getSelectedItem().toString();
        String phoneNumber = phoneNumberInput.getText();
        String password = passwordInput.getText();
        String roomType = roomTypeInput.getSelectedItem().toString();
        String status = statusInput.getSelectedItem().toString();

        boolean isValidRoomType = true;
        if (role.equalsIgnoreCase("Resident")) {
            if (!roomNumber.matches("10[1-9]|1[1-9][0-9]|200")) {
                JOptionPane.showMessageDialog(this, "Invalid Room Number for Resident!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        } else if (role.equalsIgnoreCase("Staff")) {
            if (!roomNumber.equals("305")) {
                JOptionPane.showMessageDialog(this, "Invalid Staff Code!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        } else if (role.equalsIgnoreCase("Manager")) {
            if (!roomNumber.equals("903")) {
                JOptionPane.showMessageDialog(this, "Invalid Manager Code!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        }

        if (!isValidRoomType) return; // Stop execution if room type is invalid

        String errorMessage = null;
        if (!RegisterValidator.isValidName(name)) {
            errorMessage = "Invalid name. Name must contain only letters and spaces.";
        } else if (!RegisterValidator.isValidNRIC(nric)) {
            errorMessage = "Invalid NRIC. NRIC must contain only numbers and be 12 digits long.";
        } else if (!RegisterValidator.isValidRoomNumber(roomNumber)) {
            errorMessage = "Invalid room number. Room Number must be a number between 101 and 200.";
        } else if (!RegisterValidator.isValidEmail(email)) {
            errorMessage = "Invalid email format.";
        } else if (!RegisterValidator.isValidPhoneNumber(phoneNumber)) {
            errorMessage = "Invalid phone number. Phone Number must be 10 or 11 digits long.";
        } else if (!RegisterValidator.isValidPassword(password)) {
            errorMessage = "Invalid password. Password must be provided.";
        }

        if (errorMessage != null) {
            JOptionPane.showMessageDialog(this, errorMessage, "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        model.setValueAt(name, row, 0);
        model.setValueAt(nric, row, 1);
        model.setValueAt(roomNumber, row, 2);
        model.setValueAt(email, row, 3);
        model.setValueAt(role, row, 4);
        model.setValueAt(phoneNumber, row, 5);
        model.setValueAt(password, row, 6);
        model.setValueAt(roomType, row, 7);
        model.setValueAt(status, row, 8);

        saveDataToFile1();
        saveDataToFile2();

        nameInput.setText("");
        nricInput.setText("");
        roomNumberInput.setText("");
        emailInput.setText("");
        roleInput.setSelectedIndex(0);
        phoneNumberInput.setText("");
        passwordInput.setText("");
        roomTypeInput.setSelectedIndex(0);
        statusInput.setSelectedIndex(0);
    }//GEN-LAST:event_updateActionPerformed

    private void jTable1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseReleased
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();

        String name = String.valueOf(model.getValueAt(row,0));
        String nric = String.valueOf(model.getValueAt(row,1));
        String roomNumber = String.valueOf(model.getValueAt(row,2));
        String email = String.valueOf(model.getValueAt(row,3));
        String role = String.valueOf(model.getValueAt(row,4));
        String phoneNumber = String.valueOf(model.getValueAt(row,5));
        String password = String.valueOf(model.getValueAt(row,6));
        String roomType = String.valueOf(model.getValueAt(row, 7));
        String status = String.valueOf(model.getValueAt(row, 8));

        nameInput.setText(name);
        nricInput.setText(nric);
        roomNumberInput.setText(roomNumber);
        emailInput.setText(email);
        roleInput.setSelectedItem(role);
        phoneNumberInput.setText(phoneNumber);
        passwordInput.setText(password);
        roomTypeInput.setSelectedItem(roomType);
        statusInput.setSelectedItem(status);
    }//GEN-LAST:event_jTable1MouseReleased

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        // TODO add your handling code here:
        String name = nameInput.getText();
        String nric = nricInput.getText();
        String roomNumber = roomNumberInput.getText();
        String email = emailInput.getText();
        String role = roleInput.getSelectedItem().toString();
        String phoneNumber = phoneNumberInput.getText();
        String password = passwordInput.getText();
        String roomType = roomTypeInput.getSelectedItem().toString();
        String status = statusInput.getSelectedItem().toString();

        // Room Type Validation
        boolean isValidRoomType = true;
        if (role.equalsIgnoreCase("Resident")) {
            if (!roomNumber.matches("10[1-9]|1[1-9][0-9]|200")) {
                JOptionPane.showMessageDialog(this, "Invalid Room Number for Resident!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        } else if (role.equalsIgnoreCase("Staff")) {
            if (!roomNumber.equals("305")) {
                JOptionPane.showMessageDialog(this, "Invalid Staff Code!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        } else if (role.equalsIgnoreCase("Manager")) {
            if (!roomNumber.equals("903")) {
                JOptionPane.showMessageDialog(this, "Invalid Manager Code!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                isValidRoomType = false;
            }
        }

        if (!isValidRoomType) return; // Stop execution if room type is invalid

        // Other Validation Checks
        String errorMessage = null;
        if (!RegisterValidator.isValidName(name)) {
            errorMessage = "Invalid name. Name must contain only letters and spaces.";
        } else if (!RegisterValidator.isValidNRIC(nric)) {
            errorMessage = "Invalid NRIC. NRIC must contain only numbers and be 12 digits long.";
        } else if (!RegisterValidator.isValidRoomNumber(roomNumber)) {
            errorMessage = "Invalid room number. Room Number must be a number between 101 and 200.";
        } else if (!RegisterValidator.isValidEmail(email)) {
            errorMessage = "Invalid email format.";
        } else if (!RegisterValidator.isValidPhoneNumber(phoneNumber)) {
            errorMessage = "Invalid phone number. Phone Number must be 10 or 11 digits long.";
        } else if (!RegisterValidator.isValidPassword(password)) {
            errorMessage = "Invalid password. Password must be provided.";
        }

        if (errorMessage != null) {
            JOptionPane.showMessageDialog(this, errorMessage, "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String[] values = {name, nric, roomNumber, email, role, phoneNumber, password, roomType, status};
        model.addRow(values);

        saveDataToFile1();
        saveDataToFile2();

        nameInput.setText("");
        nricInput.setText("");
        roomNumberInput.setText("");
        emailInput.setText("");
        roleInput.setSelectedIndex(0);
        phoneNumberInput.setText("");
        passwordInput.setText("");
        roomTypeInput.setSelectedIndex(0);
        statusInput.setSelectedIndex(0);
    }//GEN-LAST:event_addActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        new manager_menu_page().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(manager_manage_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(manager_manage_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(manager_manage_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(manager_manage_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new manager_manage_page().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JButton back;
    private javax.swing.JButton delete;
    private javax.swing.JLabel email;
    private javax.swing.JTextField emailInput;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel manageUserAccountTitle;
    private javax.swing.JLabel name;
    private javax.swing.JTextField nameInput;
    private javax.swing.JLabel nric;
    private javax.swing.JTextField nricInput;
    private javax.swing.JLabel password;
    private javax.swing.JTextField passwordInput;
    private javax.swing.JLabel phoneNumber;
    private javax.swing.JTextField phoneNumberInput;
    private javax.swing.JLabel role;
    private javax.swing.JComboBox<String> roleInput;
    private javax.swing.JLabel roomNumber;
    private javax.swing.JTextField roomNumberInput;
    private javax.swing.JLabel roomType;
    private javax.swing.JComboBox<String> roomTypeInput;
    private javax.swing.JLabel status;
    private javax.swing.JComboBox<String> statusInput;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
