/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oop.assignment;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 *
 * @author ezjiet
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try {
            for (UIManager.LookAndFeelInfo infor : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(infor.getName())) {
                    UIManager.setLookAndFeel(infor.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            main_page mainpage = new main_page();
            mainpage.setVisible(true);
        });
    }    
}
