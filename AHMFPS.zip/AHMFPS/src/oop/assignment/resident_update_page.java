/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package oop.assignment;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ezjiet
 */
public class resident_update_page extends javax.swing.JFrame {
    
    private String[] loginResult;

    private DefaultTableModel model = new DefaultTableModel();
    private String columnName[] = {"Name", "NRIC", "Room Number", "Email", "Role", "Phone Number", "Password", "Room Type", "Status"};
    int row = -1;

    /**
     * Creates new form updatedata_page
     */
    public resident_update_page(String[] loginResult) {
        this.loginResult = loginResult;
        initComponents();
        setLocationRelativeTo(null);

        model.setColumnIdentifiers(columnName);
        loadUserDetails(); // Load only the logged-in resident's details
    }

    private void loadUserDetails() {
        String filePath = "D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userDetails.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] values = line.split(", ");

                // Check if the logged-in resident's name matches
                if (values.length >= 9 && values[0].equalsIgnoreCase(loginResult[0])) { 
                    model.addRow(values); // Only add the logged-in resident's details to the table
                    break; // Stop reading after finding the logged-in user
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading user details.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveDataToFile1() {
        String filePath = "D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userDetails.txt";
        List<String> allUsers = new ArrayList<>();
        boolean userUpdated = false;

        // **Ensure JTable updates before reading values**
        model.fireTableDataChanged();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] values = line.split(", ");

                if (values.length >= 9 && values[0].equalsIgnoreCase(loginResult[0])) {
                    String name = model.getValueAt(0, 0).toString().trim();
                    String nric = model.getValueAt(0, 1).toString().trim();
                    String roomNumber = model.getValueAt(0, 2).toString().trim();
                    String email = model.getValueAt(0, 3).toString().trim();
                    String role = model.getValueAt(0, 4).toString().trim();
                    String phoneNumber = model.getValueAt(0, 5).toString().trim();
                    String password = model.getValueAt(0, 6).toString().trim();
                    String roomType = model.getValueAt(0, 7).toString().trim();
                    String status = model.getValueAt(0, 8).toString().trim();

                    String updatedResident = name + ", " + nric + ", " + roomNumber + ", " + email + ", " + role + ", " + phoneNumber + ", " + password + ", " + roomType + ", " + status;

                    allUsers.add(updatedResident);
                    userUpdated = true;
                } else {
                    allUsers.add(line); 
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading user details.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // **Ensure at least one user was updated**
        if (!userUpdated) {
            JOptionPane.showMessageDialog(this, "No matching user found to update!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // **🛠 Write back updated user details**
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String user : allUsers) {
                writer.write(user);
                writer.newLine();
            }
            JOptionPane.showMessageDialog(this, "User details updated successfully!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving user details.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveDataToFile2() {
        String filePath = "D:\\APU File\\Diploma Semester 4\\Object Oriented Programming\\Assignment\\txt file\\userPaymentDetails.txt";
        List<String> allPayments = new ArrayList<>();
        String updatedResidentPayment = "";

        // Read all payment details and modify the logged-in resident's payment info
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] values = line.split(", ");

                if (values.length >= 5 && values[0].equalsIgnoreCase(loginResult[0])) {
                    // Update the resident's payment details from the table
                    String name = model.getValueAt(0, 0).toString();
                    String nric = model.getValueAt(0, 1).toString();
                    String roomNumber = model.getValueAt(0, 2).toString();
                    String roomType = model.getValueAt(0, 7).toString();
                    Double balance = 0.0;

                    updatedResidentPayment = name + ", " + nric + ", " + roomNumber + ", " + roomType + ", " + balance;
                    allPayments.add(updatedResidentPayment);
                } else {
                    allPayments.add(line); // Keep other payment details unchanged
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading payment details.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Write back all payment details with the updated resident info
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String payment : allPayments) {
                writer.write(payment);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving payment details.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        updatePersonalDetails = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        password = new javax.swing.JLabel();
        nameInput = new javax.swing.JTextField();
        passwordInput = new javax.swing.JTextField();
        update = new javax.swing.JButton();
        back = new javax.swing.JButton();
        phoneNumber = new javax.swing.JLabel();
        phoneNumberInput = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(model);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable1MouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        updatePersonalDetails.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        updatePersonalDetails.setText("Update Personal Details");

        name.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        name.setText("Name :");

        password.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        password.setText("Password :");

        nameInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        passwordInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        update.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        back.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        phoneNumber.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        phoneNumber.setText("Phone Number :");

        phoneNumberInput.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(password, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(phoneNumber))
                            .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(53, 53, 53)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phoneNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(updatePersonalDetails)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 956, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name))
                        .addGap(41, 41, 41)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(phoneNumber)
                            .addComponent(phoneNumberInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(password)
                            .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(93, 93, 93)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(update)
                            .addComponent(back)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(updatePersonalDetails)
                        .addGap(55, 55, 55)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseReleased
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();

        if (row >= 0) {
            nameInput.setText(model.getValueAt(row, 0).toString());
            phoneNumberInput.setText(model.getValueAt(row, 5).toString());
            passwordInput.setText(model.getValueAt(row, 6).toString()); // Corrected index for password
        }
    }//GEN-LAST:event_jTable1MouseReleased

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        int row = jTable1.getSelectedRow();

        if (row == -1){
            JOptionPane.showMessageDialog(this, "Please select a row");
            return;
        }

        String name = nameInput.getText();
        String phoneNumber = phoneNumberInput.getText();
        String password = passwordInput.getText();
        String status = "Pending";
        
        String errorMessage = null;
        if (!RegisterValidator.isValidName(name)) {
            errorMessage = "Invalid name. Name must contain only letters and spaces.";
        } else if (!RegisterValidator.isValidPhoneNumber(phoneNumber)) {
            errorMessage = "Invalid phone number. Phone Number must be 10 or 11 digits long.";
        } else if (!RegisterValidator.isValidPassword(password)) {
            errorMessage = "Invalid password. Password must be provided.";
        }

        if (errorMessage != null) {
            JOptionPane.showMessageDialog(this, errorMessage, "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        model.setValueAt(name, row, 0);
        model.setValueAt(phoneNumber, row, 5);
        model.setValueAt(password, row, 6);

        saveDataToFile1();
        saveDataToFile2();
        
        nameInput.setText("");
        phoneNumberInput.setText("");
        passwordInput.setText("");
    }//GEN-LAST:event_updateActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        new resident_menu_page(loginResult).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(resident_update_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(resident_update_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(resident_update_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(resident_update_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                // new resident_update_page(loginResult).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel name;
    private javax.swing.JTextField nameInput;
    private javax.swing.JLabel password;
    private javax.swing.JTextField passwordInput;
    private javax.swing.JLabel phoneNumber;
    private javax.swing.JTextField phoneNumberInput;
    private javax.swing.JButton update;
    private javax.swing.JLabel updatePersonalDetails;
    // End of variables declaration//GEN-END:variables
}
